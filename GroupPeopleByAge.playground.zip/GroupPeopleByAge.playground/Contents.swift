import UIKit

struct Person {
  let firstName: String
  let lastName: String
  let age: Int
}

let marvelActors = [
  Person(firstName: "Robert", lastName: "Downey", age: 53),
  Person(firstName: "Benedict", lastName: "Cumberbatch", age: 41),
  Person(firstName: "Chris", lastName: "Pratt", age: 39),
  Person(firstName: "Chris", lastName: "Evans", age: 37),
  Person(firstName: "Scarlett", lastName: "Johansson", age: 34),
  Person(firstName: "Chris", lastName: "Hemsworth", age: 34),
  Person(firstName: "Mark", lastName: "Ruffalo", age: 50),
  Person(firstName: "Jeremy", lastName: "Renner", age: 47),
  Person(firstName: "Elizabeth", lastName: "Olsen", age: 29),
  Person(firstName: "Josh", lastName: "Brolin", age: 50),
  Person(firstName: "Tom", lastName: "Hiddleston", age: 37),
  Person(firstName: "Tom", lastName: "Holland", age: 22),
  Person(firstName: "Paul", lastName: "Rudd", age: 50),
  Person(firstName: "Karen", lastName: "Gillan", age: 31),
  Person(firstName: "Chadwick", lastName: "Boseman", age: 40),
  Person(firstName: "Zoe", lastName: "Saldana", age: 41),
  Person(firstName: "Anthony", lastName: "Mackie", age: 40),
  Person(firstName: "Benedict", lastName: "Wong", age: 47)
]

// Group Actors by Age
//let groupedDictionary = Dictionary(grouping: marvelActors) { (Person) -> Int in
//  return Person.age
//}

// Group Actors by the first character of their firstName
let groupedDictionary = Dictionary(grouping: marvelActors) { (Person) -> Character in
  return Person.firstName.first!
}

var groupedActorsByAge = [[Person]]()

let keys = groupedDictionary.keys.sorted()
keys.forEach { (key) in
  groupedActorsByAge.append(groupedDictionary[key]!)
}

groupedActorsByAge.forEach { (group) in
  group.forEach({print($0)})
  print("------------------")
}
